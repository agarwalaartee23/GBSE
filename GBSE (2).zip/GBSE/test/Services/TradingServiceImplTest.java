package Services;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import model.Stock;
import model.Trade;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import DataProvider.ReadyData;
import Services.TradingService;
import Services.TradingServiceImpl;
import exceptions.BusinessException;

public class TradingServiceImplTest {
	static TradingService instance=null;
	Map<String,Stock>stockMap=null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		instance=TradingServiceImpl.getInstance();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		stockMap=ReadyData.createData();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testGetInstance() {
		TradingService instance1=TradingServiceImpl.getInstance();
		TradingService instance2=TradingServiceImpl.getInstance();
		//assertFalse("Not same instance", instance1!=instance2);
		assertTrue("same instance", instance1==instance2);
		
	}

	@Test
	public final void testCheckSymbol() throws BusinessException {
		String symbol="Tea";
		
		boolean exist=instance.checkSymbol(symbol);
		assertTrue("Symbol does not exist",false==exist);
		
	}
	
	@Test
	public final void testCalculateDividendYield() throws BusinessException {
		String symbol="GIN";
		int price=30;
		
		double yield=instance.calculateDividendYield(symbol, price);
		assertTrue("Calculated yiled for is equal to ",yield==((.02*100)/price));
		
	}
	@Test
	public final void testCalculatePERatio() throws BusinessException{
		String symbol="GIN";
		int price=30;
		double peRatio=instance.calculatePERatio(symbol, price);
		assertTrue("Calculated PE Ration is equal to ",peRatio==price/((.02*100)/price));
		
		
	}
	@Test
	public final void testPERatioForZeroDY()throws BusinessException{
		String symbol="TEA";
		int price=30;		
		 double peRatio=instance.calculatePERatio(symbol, price);
		assertTrue("Calculated PE Ration is equal to ",peRatio==0);
		
	}
	@Test
	public final void testRecordTrade(){
		Trade trade1=new Trade();
		trade1.setStockSymbol("POP");
		trade1.setBuyOrSell(1);
		trade1.setPrice(300);
		trade1.setQunatity(100);
		trade1.setTradeId(new java.util.Random().nextLong());
		trade1.setTradingTime(System.nanoTime());
		stockMap.get(trade1.getStockSymbol()).getTradingMap().put(trade1.getTradingTime(), trade1);
		
		Trade trade2=new Trade();
		trade2.setStockSymbol("POP");
		trade2.setBuyOrSell(0);
		trade2.setPrice(300);
		trade2.setQunatity(10);
		trade2.setTradeId(new java.util.Random().nextLong());
		trade2.setTradingTime(System.nanoTime());
		stockMap.get(trade2.getStockSymbol()).getTradingMap().put(trade2.getTradingTime(), trade2);
		System.out.println(stockMap.get("POP").getTradingMap().size());
		
		assertTrue("total trades conducted is 2", stockMap.get("POP").getTradingMap().size()==2);
		
	}
	@Test
	public final void testVSWP(){
		Trade trade1=new Trade();
		trade1.setStockSymbol("POP");
		trade1.setBuyOrSell(1);
		trade1.setPrice(300);
		trade1.setQunatity(100);
		trade1.setTradeId(new java.util.Random().nextLong());
		trade1.setTradingTime(System.nanoTime());
		stockMap.get(trade1.getStockSymbol()).getTradingMap().put(trade1.getTradingTime(), trade1);
		
		Trade trade2=new Trade();
		trade2.setStockSymbol("POP");
		trade2.setBuyOrSell(0);
		trade2.setPrice(300);
		trade2.setQunatity(10);
		trade2.setTradeId(new java.util.Random().nextLong());
		trade2.setTradingTime(System.nanoTime());
		stockMap.get(trade2.getStockSymbol()).getTradingMap().put(trade2.getTradingTime(), trade2);
		
		String symbol="POP";
		int duration=2;		
		System.out.println("data--"+stockMap.get("POP").getTradingMap().size());
		 double vwsp=instance.calculateVWSP(symbol, duration);
		 System.out.println("VWSP="+vwsp);
		assertTrue("Calculated Volume weighted price equal to ",vwsp==(300*100-300*10)/90);
	}
	@Test
	public final void testCalGM(){
		getData();
		double gm=instance.calculateGeometricMean();
		
		assertTrue("Gm is ",gm==84.34326653017494);
		
		
	}
	
	private Map<String,Stock> getData(){
		Trade trade1=new Trade();
		trade1.setStockSymbol("POP");
		trade1.setBuyOrSell(1);
		trade1.setPrice(300);
		trade1.setQunatity(100);
		trade1.setTradeId(new java.util.Random().nextLong());
		trade1.setTradingTime(System.nanoTime());
		stockMap.get(trade1.getStockSymbol()).getTradingMap().put(trade1.getTradingTime(), trade1);
		
		Trade trade2=new Trade();
		trade2.setStockSymbol("POP");
		trade2.setBuyOrSell(0);
		trade2.setPrice(300);
		trade2.setQunatity(10);
		trade2.setTradeId(new java.util.Random().nextLong());
		trade2.setTradingTime(System.nanoTime());
		stockMap.get(trade2.getStockSymbol()).getTradingMap().put(trade2.getTradingTime(), trade2);
		
		Trade trade3=new Trade();
		trade3.setStockSymbol("GIN");
		trade3.setBuyOrSell(1);
		trade3.setPrice(100);
		trade3.setQunatity(1010);
		trade3.setTradeId(new java.util.Random().nextLong());
		trade3.setTradingTime(System.nanoTime());
		stockMap.get(trade3.getStockSymbol()).getTradingMap().put(trade3.getTradingTime(), trade3);
		
		Trade trade4=new Trade();
		trade4.setStockSymbol("ALE");
		trade4.setBuyOrSell(1);
		trade4.setPrice(20);
		trade4.setQunatity(10);
		trade4.setTradeId(new java.util.Random().nextLong());
		trade4.setTradingTime(System.nanoTime());
		stockMap.get(trade4.getStockSymbol()).getTradingMap().put(trade4.getTradingTime(), trade4);
		
		return stockMap;
		
	}

}
