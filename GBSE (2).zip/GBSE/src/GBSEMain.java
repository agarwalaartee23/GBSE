import java.util.Scanner;

import Services.TradingService;
import Services.TradingServiceImpl;
import Utilities.CommonFunctions;
import exceptions.BusinessException;

public class GBSEMain {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);

		String option = "";

		do {
			option = getOptions(scnr);

		} while (!option.equalsIgnoreCase("6"));
	}

	private static void callMe(String option, Scanner scanner) {
		

		switch (option) {
		// will calculate Dividend Yield
		case "1":
			calculateDY(scanner);
			getOptions(scanner);

			break;

		case "2":
			// will calculate PE Ratio
			callPERatio(scanner);
			getOptions(scanner);
			break;
		case "3":
			// Will record trade
			recordTrade(scanner);
			getOptions(scanner);

			break;
		case "4":
			// will calculate Weighted Volume stock price for given
			// stock and duration
			calVWSP(scanner);
			getOptions(scanner);
			break;
		case "5":
			// will calculate GM for all the stock traded
			callGM();
			getOptions(scanner);

			break;
		case "6":
			scanner.close();
			System.out.println("Program terminated.Thanks");
			System.exit(1);

		default:
			break;
		}

	}

	public static String getOptions(Scanner scnr) {
		
		System.out.println();
		System.out.println("Choose 1: Calculate Dividend Yield");
		System.out.println("Choose 2: Calculate PE Ratio");
		System.out.println("Choose 3: Want to do the trading.");
		System.out
				.println("Choose 4: Calculate Volume Weighted Stock price happend in last given minutes.");
		System.out.println("Choose 5: Calculate GBSE index for all stocks. ");
		System.out.println("Choose 6: Press 6 to exit ");
		System.out.println();
		String option = scnr.next();
		callMe(option, scnr);
		
		return option;
	}

	private static void calculateDY(Scanner scanner) {
		
		try {
			TradingService service = TradingServiceImpl.getInstance();
			int price = 0;
			String symbol = "";
			do {
				System.out.println("Please enter valid StockSymbol.");
				symbol = scanner.next();

			} while (!service.checkSymbol(symbol));

			System.out.println("Please enter price in pennies");

			do {
				String str=scanner.next();
				price=CommonFunctions.validateNumberInput(str);
				if (price <= 0)
					System.out.println("Please enter valid price .");

			} while (price <= 0);
			

			Double yeild = service.calculateDividendYield(symbol, price);

			System.out.println("Dividend yield for stock "+symbol +" is =" + String.format("%.2f", yeild));
			

		} catch (BusinessException e1) {
			
			e1.getMessage();

		}
	}

	private static void callPERatio(Scanner scanner) {
		
		try {
			TradingService service = TradingServiceImpl.getInstance();
			int price = 0;
			String symbol = "";
			do {
				System.out.println("Please enter valid StockSymbol.");
				symbol = scanner.next();

			} while (!service.checkSymbol(symbol));

			System.out.println("Please enter price in pennies");

			do {
				String str=scanner.next();
				price=CommonFunctions.validateNumberInput(str);
				if (price <= 0)
					System.out.println("Please enter valid price .");

			} while (price <= 0);
			

			Double PERatio = service.calculatePERatio(symbol, price);
			System.out.println("PE Ratio for stock "+symbol +" is ="  + String.format("%.2f", PERatio));
			
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			
		}
	}

	private static void recordTrade(Scanner scanner) {
		
		int qnty = 0;
		String symbol = "";
		int price = 0;
		int buySell = 0;

		TradingService service = TradingServiceImpl.getInstance();
		try{
		
		do {
			System.out.println("Please enter valid StockSymbol.");
			symbol = scanner.next();

		} while (!service.checkSymbol(symbol));
		System.out.println("Please enter price in pennies");
		price = 0;

		do {String str=scanner.next();
			price=CommonFunctions.validateNumberInput(str);
			if (price <= 0)
				System.out.println("Please enter valid price .");

		} while (price <= 0);

		System.out.println("please enter quantity .");
		do {
			
			String str=scanner.next();
			qnty=CommonFunctions.validateNumberInput(str);
			if (qnty <= 0) {
				System.out.println("Please enter valid quantity");

			}
		} while (qnty <= 0);
		
		System.out.println("Please enter 1 for Buy or 0 for Sell");

		do {
		
			String str=scanner.next();
			buySell=CommonFunctions.validateNumberInput(str);
			if(buySell>=2 || buySell<0){
				System.out.println("Please enter 1 for Buy or 0 for Sell");
			}
			

		} while (buySell >= 2 || buySell < 0);

		
			service.trade(symbol, price, qnty, buySell);

		} catch (BusinessException e) {

			e.getMessage();
		}
	}

	private static void calVWSP(Scanner scanner) {
		int duration = 0;
		String symbol = "";
		TradingService service = TradingServiceImpl.getInstance();

		try{
		
		do {
			System.out.println("Please enter valid StockSymbol.");
			symbol = scanner.next();

		} while (!service.checkSymbol(symbol));

		System.out.println("Please enter duration in minutes");

		do {
			String str=scanner.next();
			duration=CommonFunctions.validateNumberInput(str);
			if (duration <= 0)
				System.out.println("Please enter valid time in minutes .");

		} while (duration <= 0);

		double net = service.calculateVWSP(symbol, duration);
		System.out
				.println("Calculated Volume Weighted Stock price of trades of stock "
						+ symbol
						+ " happend in last "
						+ duration
						+ " minutes is = " + String.format("%.3f", net));
		
		}catch(BusinessException ex){ex.getMessage();}

	}

	private static void callGM() {
		TradingService service = TradingServiceImpl.getInstance();
		double gm = service.calculateGeometricMean();
		System.out.println("Geometric mean index of all stocks traded is="
				+ String.format("%.3f", gm));
	}
}
