package Utilities;

import java.util.List;

public class CommonFunctions {

	public static double geometricMean(List<Double> x) {
		int n = x.size();
		double GM_log = 0.0d;
		for (int i = 0; i < n; ++i) {
			if (x.get(i) == 0.0) {
				return 0.0d;
			}
			GM_log += Math.log(x.get(i));
		}
		
		if(GM_log>0 && n>0)
			return Math.exp(GM_log/n);
		else return GM_log;
	}
	
	public static int validateNumberInput(String str){
		int price=-1;
		try{price = Integer.parseInt(str);}
		catch(NumberFormatException nfe){
			
			return price=-1;
		}
		return price;
	}
}
