package Services;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

import model.Stock;
import model.Trade;
import DataProvider.ReadyData;
import Utilities.CommonFunctions;
import exceptions.BusinessException;

public class TradingServiceImpl implements TradingService {
	
	//one and only one instance is required for this service
	    private TradingServiceImpl() {
	        
	    }
	 
	    private static class InstanceHolder {
	        public static final TradingService INSTANCE = new TradingServiceImpl();
	    }
	 
	    public static TradingService getInstance() {
	        return InstanceHolder.INSTANCE;
	    }
	 
	   
	
	
	
	Map<String, Stock> map = ReadyData.createData();
	@Override
	public boolean checkSymbol(String symbol) throws BusinessException{
		if(map.containsKey(symbol))
			return true;
		else 
			return false;
	}

	@Override
	public Double calculateDividendYield(String stockSymbol, Integer price)
			 {
		Double diviYeild = 0.0;

	
			Stock stk = map.get(stockSymbol);
			if (stk.getFixedDividend() == null) {
				diviYeild = (double) (stk.getLastDividend()) / price;
			} else if (stk.getFixedDividend() != null) {
				diviYeild = ((stk.getFixedDividend() * stk.getParValue()) / price);

			}
			
		
		return diviYeild;
	}

	@Override
	public Double calculatePERatio(String stockSymbol, Integer price)
			throws BusinessException {
		Double peRatio = 0.0;

		
			
			double yield=calculateDividendYield(stockSymbol, price);
			if(yield!=0)

			peRatio = price / yield;
			
			else
				return peRatio;

		
		return peRatio;
	}

	@Override
	public Long trade(String stockSymbol, Integer price, Integer qty,
			Integer sellBuy) throws BusinessException {

		Trade trade = null;
		
			trade = new Trade();
			trade.setBuyOrSell(sellBuy);
			trade.setPrice(price);
			trade.setStockSymbol(stockSymbol);
			trade.setTradingTime(System.nanoTime());
			trade.setTradeId(new java.util.Random().nextLong());
			trade.setQunatity(qty);
			map.get(stockSymbol).getTradingMap().put(trade.getTradingTime(), trade);

		
		return trade.getTradeId();

	}

	@Override
	public Double calculateVWSP(String stockSymbol, Integer duration) {
		double volumeSP = 0.0;
		int totalQty = 0;
		double net = 0.0;
		
			Stock stock = map.get(stockSymbol);
			Map<Long, Trade> trades = stock.getTradingMap();
			Long timeto = System.nanoTime();
			Long timefrom = timeto - (duration * 60 * 1000*1000000);
			SortedSet<Long> time = (SortedSet<Long>) trades.keySet();
			time.headSet(timefrom);
			//time.removeAll(olderTrade);
			Iterator<Long> it = time.iterator();
			while (it.hasNext()) {
				Trade t1 = trades.get(it.next());
				if (t1.getBuyOrSell() == 1) {
					volumeSP += t1.getPrice() * t1.getQunatity();
					totalQty += t1.getQunatity();
				}
				if (t1.getBuyOrSell() == 0) {
					volumeSP -= t1.getPrice() * t1.getQunatity();
					totalQty -= t1.getQunatity();
				}

			}
			if (volumeSP > 0 && totalQty > 0)
				net = volumeSP / totalQty;
			return net;

		
	}

	@Override
	public Double calculateGeometricMean() {
		
		List<Double> vswp = new ArrayList<Double>();
		double net = 0.0;

		Set<String> stocks = map.keySet();
		Iterator<String> stkIt = stocks.iterator();
		while (stkIt.hasNext()) {

			Stock stock = map.get(stkIt.next());
			Map<Long, Trade> trades = stock.getTradingMap();
			if(trades!=null && trades.size()>0){

			Iterator<Long> it = trades.keySet().iterator();
			Trade t1=null;
			double volumeSP = 0.0;
			int totalQty = 0;
			while (it.hasNext()) {
				 t1 = trades.get(it.next());
				if (t1.getBuyOrSell() == 1) {
					volumeSP += t1.getPrice() * t1.getQunatity();
					totalQty += t1.getQunatity();
				}
				if (t1.getBuyOrSell() == 0) {
					volumeSP -= t1.getPrice() * t1.getQunatity();
					totalQty -= t1.getQunatity();
				}

			}
			
			if (volumeSP > 0 && totalQty > 0) {
				net = volumeSP / totalQty;
			}

			vswp.add(net);
		}
			}
		double geoMean = CommonFunctions.geometricMean(vswp);

		return geoMean;
	}

	

}
