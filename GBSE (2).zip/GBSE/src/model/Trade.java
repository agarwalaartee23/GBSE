package model;


public class Trade {
	private String stockSymbol;
	private Integer price;
	private Integer buyOrSell;
	private Long tradeId;
	private Long tradingTime;
	private Integer qunatity;
	public String getStockSymbol() {
		return stockSymbol;
	}
	public void setStockSymbol(String stockSymbol) {
		this.stockSymbol = stockSymbol;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Integer getBuyOrSell() {
		return buyOrSell;
	}
	public void setBuyOrSell(Integer buyOrSell) {
		this.buyOrSell = buyOrSell;
	}
	public Long getTradeId() {
		return tradeId;
	}
	public void setTradeId(Long tradeId) {
		this.tradeId = tradeId;
	}
	public Long getTradingTime() {
		return tradingTime;
	}
	public void setTradingTime(Long tradingTime) {
		this.tradingTime = tradingTime;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (buyOrSell==1 ? 1231 : 1237);
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result
				+ ((stockSymbol == null) ? 0 : stockSymbol.hashCode());
		result = prime * result + ((tradeId == null) ? 0 : tradeId.hashCode());
		result = prime * result
				+ ((tradingTime == null) ? 0 : tradingTime.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Trade other = (Trade) obj;
		if (buyOrSell != other.buyOrSell)
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (stockSymbol == null) {
			if (other.stockSymbol != null)
				return false;
		} else if (!stockSymbol.equals(other.stockSymbol))
			return false;
		if (tradeId == null) {
			if (other.tradeId != null)
				return false;
		} else if (!tradeId.equals(other.tradeId))
			return false;
		if (tradingTime == null) {
			if (other.tradingTime != null)
				return false;
		} else if (!tradingTime.equals(other.tradingTime))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Trade [stockSymbol=" + stockSymbol + ", price=" + price
				+ ", buyOrSell=" + buyOrSell + ", tradeId=" + tradeId
				+ ", tradingTime=" + tradingTime + "]";
	}
	public Integer getQunatity() {
		return qunatity;
	}
	public void setQunatity(Integer qunatity) {
		this.qunatity = qunatity;
	}
	
	

}
