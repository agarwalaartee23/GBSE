package model;
import java.util.SortedMap;


public class Stock {
	
public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public Integer getLastDividend() {
		return lastDividend;
	}
	public void setLastDividend(Integer lastDividend) {
		this.lastDividend = lastDividend;
	}
	public Double getFixedDividend() {
		return fixedDividend;
	}
	public void setFixedDividend(Double fixedDividend) {
		this.fixedDividend = fixedDividend;
	}
	public Integer getParValue() {
		return parValue;
	}
	public void setParValue(Integer parValue) {
		this.parValue = parValue;
	}
	public SortedMap<Long, Trade> getTradingMap() {
		return tradingMap;
	}
	public void setTradingMap(SortedMap<Long,Trade> tradingMap) {
		this.tradingMap = tradingMap;
	}
	public Double getDividendYield() {
		return dividendYield;
	}
	public void setDividendYield(Double diviYeild) {
		this.dividendYield = diviYeild;
	}
private String symbol;
private Integer lastDividend;
private Double fixedDividend;
private Integer parValue;
private SortedMap<Long,Trade> tradingMap;
private Double dividendYield;

	
	
	
}
