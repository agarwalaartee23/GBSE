package DataProvider;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import model.Stock;
import model.Trade;


public class ReadyData {
	//no other thread can change data of stocks only trades can be addded
	static final Map <String,Stock>stockMap=new HashMap<String,Stock>();;
	
	
	public static Map<String,Stock>  createData() {
		
		Stock teaStock=new Stock();
		teaStock.setSymbol("TEA");
		teaStock.setLastDividend(0);
		teaStock.setFixedDividend(null);
		teaStock.setParValue(100);
		teaStock.setTradingMap(new TreeMap<Long,Trade>());
		
		Stock PooStock=new Stock();
		PooStock.setSymbol("POP");
		PooStock.setLastDividend(8);
		PooStock.setFixedDividend(null);
		PooStock.setParValue(100);
		PooStock.setTradingMap(new TreeMap<Long,Trade>());
		
		Stock AleStock=new Stock();
		AleStock.setSymbol("ALE");
		AleStock.setLastDividend(23);
		AleStock.setFixedDividend(null);
		AleStock.setParValue(60);
		AleStock.setTradingMap(new TreeMap<Long,Trade>());
		
		Stock GINStock=new Stock();
		GINStock.setSymbol("GIN");
		GINStock.setLastDividend(8);
		GINStock.setFixedDividend(.02);
		GINStock.setParValue(100);
		GINStock.setTradingMap(new TreeMap<Long,Trade>());
		
		Stock JOE=new Stock();
		JOE.setSymbol("JOE");
		JOE.setLastDividend(13);
		JOE.setFixedDividend(null);
		JOE.setParValue(250);
		JOE.setTradingMap(new TreeMap<Long,Trade>());
		
		
		stockMap.put("TEA",teaStock);
		stockMap.put("POP",PooStock);
		stockMap.put("ALE",AleStock);
		
		stockMap.put("GIN",GINStock);
		stockMap.put("JOE",JOE);
		
		return stockMap;
		
		
		
		
	}
	

	

}
