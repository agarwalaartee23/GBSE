package Services;
import exceptions.BusinessException;


public interface TradingService {
	
	public Double calculateDividendYield(String stockSymbol,Integer price) ;
	public Double calculatePERatio(String stockSymbol,Integer price) throws BusinessException;
	public Long trade(String stockSymbol,Integer price,Integer qty,Integer sellBuy) throws BusinessException;
	public Double calculateVWSP(String stockSymbol,Integer duration);
	Double calculateGeometricMean();
	boolean checkSymbol(String symbol) throws BusinessException;
	

}
